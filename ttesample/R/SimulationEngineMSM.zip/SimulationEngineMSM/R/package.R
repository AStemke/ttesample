#' `SimulationEngineMSM` Package
#'
#' `SimulationEngineMSM` does ...
#'
"_PACKAGE"

#' @import checkmate
#' @importFrom stats acf
NULL
