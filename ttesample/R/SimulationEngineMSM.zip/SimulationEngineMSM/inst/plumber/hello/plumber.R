#* Personal greeting as a Plumber API
#* @param name Your name (character string; e.g. "john doe").
#* @get /echo
SimulationEngineMSM::hello
